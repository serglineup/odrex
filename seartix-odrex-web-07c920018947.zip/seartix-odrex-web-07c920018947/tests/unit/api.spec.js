import {assert} from 'chai'
import {describe, it} from 'mocha';

import clientLogin from '../../src/api/client/login';
import clientInfo from '../../src/api/client/info';
import clientRegister from '../../src/api/client/register'

import doctorsList from '../../src/api/doctors/list';
import doctorsSchedule from '../../src/api/doctors/schedule';

import diagnosticsList from '../../src/api/diagnostics/list';
import diagnosticsSchedule from '../../src/api/diagnostics/schedule';

import analyzesList from '../../src/api/analyzes/list';
import analyzesShow from '../../src/api/analyzes/show';

import visitsCurrent from '../../src/api/visits/current';
import visitsCurrentCancel from '../../src/api/visits/current-cancel';
import visitsDocument from '../../src/api/visits/document';
import visitsPast from '../../src/api/visits/past';

import diagnosticTypes from '../../src/api/diagnostic-types';

import specializations from '../../src/api/specializations';

import clinics from '../../src/api/clinics';

import sliders from '../../src/api/sliders';

const getToken = () => {
    const login = 'test4';
    const password = '123456';
    const smsCode = '1234567890';

    return clientLogin({
        login,
        password,
    })
        .then(() => {
            return clientLogin({
                login,
                password,
                sms_code: smsCode,
            })
                .then(({id, api_token}) => {
                    return api_token;
                })
        })
};

describe('Api', function () {
    this.timeout(10000);

    // describe('Client', function () {
    //     const login = 'test4';
    //
    //     const validPassword = '123456';
    //     const invalidPassword = '1234567';
    //
    //     const validSmsCode = '1234567890';
    //     const invalidSmsCode = '1234567891';
    //
    //     const name = 'Test';
    //     const birthday = '01.01.2000';
    //     const phone = '38(099)999-99-99';
    //     const registerLogin = 'Test' + (new Date()).getTime();
    //     const email = 'test@mail.com';
    //     const address = 'Test address';
    //
    //     describe('Login', function () {
    //         it('invalid_credentials', function () {
    //             return clientLogin({
    //                 login,
    //                 password: invalidPassword,
    //             })
    //                 .catch(({message}) => {
    //                     assert.equal(message, 'invalid_credentials');
    //                 });
    //         });
    //
    //         it('need_sms_code', function () {
    //             return clientLogin({
    //                 login,
    //                 password: validPassword,
    //             })
    //                 .then(() => {
    //                     return clientLogin({
    //                         login,
    //                         password: validPassword,
    //                     })
    //                 })
    //                 .catch(({message}) => {
    //                     assert.equal(message, 'need_sms_code');
    //                 });
    //         });
    //
    //         it('invalid_sms_code', function () {
    //             return clientLogin({
    //                 login,
    //                 password: validPassword,
    //                 sms_code: invalidSmsCode,
    //             })
    //                 .catch((error) => {
    //                     assert.equal(error.message, 'invalid_sms_code');
    //                 });
    //         });
    //
    //         it('all_success', function () {
    //             return clientLogin({
    //                 login,
    //                 password: validPassword,
    //                 sms_code: validSmsCode,
    //             })
    //         });
    //     });
    //
    //     describe('Info', function () {
    //         it('all_success', function () {
    //             return clientLogin({
    //                 login,
    //                 password: validPassword,
    //             })
    //                 .then(() => {
    //                     return clientLogin({
    //                         login,
    //                         password: validPassword,
    //                         sms_code: validSmsCode,
    //                     });
    //                 })
    //                 .then(({id, api_token}) => {
    //                     return clientInfo({api_token});
    //                 });
    //         });
    //     });
    //
    //     describe('Registration', function () {
    //         it('all_success', function () {
    //             return clientRegister({
    //                 name,
    //                 birthday,
    //                 phone,
    //
    //                 login: registerLogin,
    //                 password: validPassword,
    //
    //                 email,
    //                 address,
    //             });
    //         });
    //
    //         it('login_already_exists', function () {
    //             return clientRegister({
    //                 name,
    //                 birthday,
    //                 phone,
    //
    //                 login: registerLogin,
    //                 password: validPassword,
    //
    //                 email,
    //                 address,
    //             })
    //                 .catch(({message}) => {
    //                     assert.equal(message, 'login_already_exists');
    //                 });
    //         });
    //     });
    // });

    describe('Diagnostics', function () {
        it('List', function () {
            return diagnosticsList();
        });

        it('Schedule', function () {
            return diagnosticsList()
                .then(diagnostics => {
                    for (let diagnostic of diagnostics) {
                        if (diagnostic.clinics.length > 0) {
                            return diagnostic;
                        }
                    }
                })
                .then(diagnostic => {
                    if (diagnostic) {
                        return diagnosticsSchedule({
                            diagnostic_id: diagnostic.id,
                            clinic_id: diagnostic.clinics[0],
                        });
                    }
                });
        });
    });

    describe('Doctors', function () {
        it('List', function () {
            return doctorsList();
        });

        it('Schedule', function () {
            return doctorsList()
                .then(doctors => {
                    for (let doctor of doctors) {
                        if (doctor.specializations.length > 0 && doctor.clinics.length > 0) {
                            return doctor;
                        }
                    }
                })
                .then(doctor => {
                    if (doctor) {
                        return doctorsSchedule({
                            doctor_id: doctor.id,
                            specialization_id: doctor.specializations[0],
                            clinic_id: doctor.clinics[0],
                        });
                    }
                });
        });
    });

    // describe('Analyzes', function () {
    //     it('List', function () {
    //         return getToken()
    //             .then(api_token => {
    //                 return analyzesList({api_token});
    //             });
    //     });
    //
    //     it('Show', async function () {
    //         let api_token = await getToken();
    //
    //         return analyzesList({api_token})
    //             .then(analyzes => {
    //                 return analyzes[0];
    //             })
    //             .then(analyze => {
    //                 return analyzesShow({analyze_id: analyze.id, api_token});
    //             });
    //     });
    // });

    // describe('Visits', function () {
    //     it('Current', function () {
    //         return getToken()
    //             .then(api_token => {
    //                 return visitsCurrent({api_token});
    //             });
    //     });
    //
    //     it('Past', function () {
    //         return getToken()
    //             .then(api_token => {
    //                 return visitsPast({api_token});
    //             });
    //     });
    //
    //     it('Document', async function () {
    //         let api_token = await getToken();
    //
    //         return visitsPast({api_token})
    //             .then(visits => {
    //                 for (let visit of visits) {
    //                     if (visit.document) {
    //                         return visit;
    //                     }
    //                 }
    //             })
    //             .then(visit => {
    //                 return visitsDocument({visit_id: visit.id, api_token});
    //             });
    //     });
    // });

    // describe('Diagnostic Types', function () {
    //     it('all_success', function () {
    //         return diagnosticTypes();
    //     });
    // });

    // describe('Specializations', function () {
    //     it('all_success', function () {
    //         return specializations();
    //     });
    // });

    // describe('Clinics', function () {
    //     it('all_success', function () {
    //         return clinics();
    //     });
    // });

    // describe('Sliders', function () {
    //     it('all_success', function () {
    //         return sliders();
    //     });
    // });
});
