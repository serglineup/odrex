export class ApplicationError extends Error {
}
