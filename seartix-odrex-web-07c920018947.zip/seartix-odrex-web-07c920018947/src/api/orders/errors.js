import {ApplicationError} from "../errors";

export class InvalidSmsCodeOrTokenError extends ApplicationError {
}