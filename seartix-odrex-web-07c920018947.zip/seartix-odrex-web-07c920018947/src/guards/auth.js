import store from '../store';

export function isLoggedIn(to, from, next) {
    if (store.getters.isLoggedIn) {
        next();
        return;
    }

    next({
        name: 'login',
    });
}

export function isGuest(to, from, next) {
    if (store.getters.isGuest) {
        next();
        return;
    }

    if (from) {
        next({
            name: from.name,
        });
        return;
    }

    next({
        name: 'profile',
    });
}

export function ifAuthRedirect(where) {
    return function (to, from, next) {
        if (store.getters.isLoggedIn) {
            next({
                name: where,
                query: to.query,
            });
            return;
        }

        next();
    }
}
