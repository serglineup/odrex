<template>
    <div class="logo text-center">
        <img src="~@/assets/images/logo.svg" alt="odrex">
    </div>
</template>

<script>
    export default {
        name: 'logo'
    }
</script>

<style scoped lang="scss">
    .logo {
        & > img {
            width: 107.4px;
            height: 30px;
        }
    }
</style>
