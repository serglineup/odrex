import Vue from 'vue'
import Vuex from 'vuex'

import createPersistedState from 'vuex-persistedstate';

import getSettings from '../api/settings/list'

import login from '../api/client/login'
import info from '../api/client/info'
import register from '../api/client/register';
import restorePassword from '../api/client/restore-password';
import changePassword from '../api/client/change-password';

import getAnalyzes from '../api/analyzes/list'
import getAnalyze from '../api/analyzes/show'

import getVisitsCurrent from '../api/visits/current'
import getVisitsPaymentLink from '../api/visits/payment-link'
import setVisitsCurrentCancel from '../api/visits/current-cancel'
import getVisitDocument from '../api/visits/document'
import getVisitsPast from '../api/visits/past'

import getDoctors from '../api/doctors/list'
import getDoctorTimeTables from '../api/doctors/time-tables'
import getDoctorTimeTableInfo from '../api/doctors/time-table-info'

import getDiagnostics from '../api/diagnostics/list'
import getDiagnosticTimeTables from '../api/diagnostics/time-tables'
import getDiagnosticTimeTableInfo from '../api/diagnostics/time-table-info'

import orderDoctorTimeTable from '../api/orders/order-doctor-time-table'
import {orderGuestDoctorTimeTable} from '../api/orders/order-doctor-time-table'
import {confirmGuestDoctorTimeTable} from '../api/orders/order-doctor-time-table'
import orderDoctor from '../api/orders/order-doctor'
import orderDiagnosticTimeTable from '../api/orders/order-diagnostic-time-table'
import {orderGuestDiagnosticTimeTable} from '../api/orders/order-diagnostic-time-table'
import {confirmGuestDiagnosticTimeTable} from '../api/orders/order-diagnostic-time-table'

import getSpecializations from '../api/specializations'
import getDiagnosticTypes from '../api/diagnostic-types'

import getClinics from '../api/clinics'

import getSliders from '../api/sliders'
import {ApplicationError} from '../api/errors';

Vue.use(Vuex);

const store = new Vuex.Store({
    plugins: [
        createPersistedState(),
    ],
    state: {
        error: null,
        success: null,
        auth: {
            user: {
                id: null,
                login: null,
                name: null,
                birthday: null,
                phone: null,
                address: null,
                email: null,
                confirm_email: null,
                available_record_today: null,
            },
            api_token: null,
        },
        analyzes: [],
        visitsPast: [],
        visitsCurrent: [],
        settings: {},
    },
    getters: {
        isLoggedIn: state => state.auth.api_token !== null,
        isGuest: state => state.auth.api_token === null,

        diagnosticsVisitPast: state => {
            if (state.visitsPast) {
                return state.visitsPast.filter(visitPast => visitPast.diagnostic !== null);
            }

            return [];
        },
        diagnosticsVisitCurrent: state => {
            if (state.visitsCurrent) {
                return state.visitsCurrent.filter(visitCurrent => visitCurrent.diagnostic !== null);
            }

            return [];
        },

        consultationsVisitPast: state => {
            if (state.visitsPast) {
                return state.visitsPast.filter(visitPast => visitPast.specialization !== null);
            }

            return [];
        },
        consultationsVisitCurrent: state => {
            if (state.visitsCurrent) {
                return state.visitsCurrent.filter(visitCurrent => visitCurrent.specialization !== null);
            }

            return [];
        },

        visitPastUnreadCount: state => {
            if (state.visitsPast) {
                return state.visitsPast.filter(visitPast => !visitPast.read).length;
            }

            return 0;
        },
        visitCurrentUnreadCount: state => {
            if (state.visitsCurrent) {
                return state.visitsCurrent.filter(visitCurrent => !visitCurrent.read).length;
            }

            return 0;
        },
        diagnosticsPastUnreadCount: state => {
            if (state.visitsPast) {
                return state.visitsPast
                    .filter(visitPast => visitPast.diagnostic !== null)
                    .filter(visitPast => !visitPast.read).length;
            }

            return 0;
        },
        diagnosticsCurrentUnreadCount: state => {
            if (state.visitsCurrent) {
                return state.visitsCurrent
                    .filter(visitCurrent => visitCurrent.diagnostic !== null)
                    .filter(visitCurrent => !visitCurrent.read).length;
            }

            return 0;
        },
        consultationsPastUnreadCount: state => {
            if (state.visitsPast) {
                return state.visitsPast
                    .filter(visitPast => visitPast.specialization !== null)
                    .filter(visitPast => !visitPast.read).length;
            }

            return 0;
        },
        consultationsCurrentUnreadCount: state => {
            if (state.visitsCurrent) {
                return state.visitsCurrent
                    .filter(visitCurrent => visitCurrent.specialization !== null)
                    .filter(visitCurrent => !visitCurrent.read).length;
            }

            return 0;
        },
        analyzesUnreadCount: state => {
            if (state.analyzes) {
                return state.analyzes.filter(analyze => !analyze.read).length;
            }

            return 0;
        },
    },
    mutations: {
        apiToken(state, payload) {
            state.auth.api_token = payload;
        },
        authUser(state, payload) {
            state.auth.user = payload;

            if (process.env.VUE_APP_ODREX_UA === 'true') {
                if (state.auth.user.id) {
                    window.$('#odrex-vue-not-logged').hide();

                    window.$('#odrex-vue-profile').show();
                    window.$('#odrex-vue-profile > a > span').html(state.auth.user.name);
                } else {
                    window.$('#odrex-vue-not-logged').show();

                    window.$('#odrex-vue-profile > a > span').html('');
                    window.$('#odrex-vue-profile').hide();
                }
            }
        },
        analyzes(state, payload) {
            state.analyzes = payload;
        },
        visitsPast(state, payload) {
            state.visitsPast = payload;
        },
        visitsCurrent(state, payload) {
            state.visitsCurrent = payload;
        },
        error(state, payload) {
            state.error = payload;
        },
        success(state, payload) {
            state.success = payload;
        },
        settings(state, payload) {
            state.settings = payload;

            if (process.env.VUE_APP_ODREX_UA === 'true') {
                if (state.auth.user.id) {
                    window.$('#odrex-vue-not-logged').hide();

                    window.$('#odrex-vue-profile').show();
                    window.$('#odrex-vue-profile > a > span').html(state.auth.user.name);
                } else {
                    window.$('#odrex-vue-not-logged').show();

                    window.$('#odrex-vue-profile > a > span').html('');
                    window.$('#odrex-vue-profile').hide();
                }
            }
        },
    },
    actions: {
        handleError({state, commit, dispatch}, error) {
            if (error instanceof ApplicationError) {
                throw error;
            }

            if (error.response.status >= 500) {
                commit('error', 'Включен режим технического обслуживания. Повторите попытку позже.');
                dispatch('logout');
                return null;
            }

            const {response: {data: {errors = []}}} = error;

            if (errors.includes(4)) {
                commit('error', 'Время сессии истекло. Авторизуйтесь заново.');
                dispatch('logout');
                return null;
            }

            if (errors.includes(6076)) {
                commit('error', 'Ваш номер телефона заблокирован.');
                dispatch('logout');
                return null;
            }

            if (errors.includes(6077)) {
                commit('error', 'Вы достигли лимита для отправки заказов.');
                dispatch('logout');
                return null;
            }

            throw error;
        },
        handleSuccess({state, commit, dispatch}, success) {
            commit('success', success);
        },
        getSettings({commit, dispatch}) {
            return getSettings()
                .then(settings => {
                    commit('settings', settings);
                })
                .catch(error => dispatch('handleError', error));
        },
        login({commit, dispatch}, payload) {
            return login(payload)
                .catch(error => dispatch('handleError', error))
                .then(({api_token}) => {
                    commit('apiToken', api_token);
                    return info(api_token);
                })
                .then(({
                           id, login, name, birthday, phone, address, email, confirm_email, confirm_phone,
                           available_record_today
                       }) => {
                    console.debug('LOGIN');

                    commit('authUser', {
                        id,
                        login,
                        name,
                        birthday,
                        phone,
                        address,
                        email,
                        confirm_email,
                        confirm_phone,
                        available_record_today,
                    });     
                    console.log("LOGIN");  
                    document.getElementById('odrex-vue-wrapper').style.display = 'none';                    
                    // console.log(c);  
                        
                });
            
        },
        logout({commit}, reload = true) {
            console.debug('LOGOUT');

            commit('authUser', {
                id: null,
                login: null,
                name: null,
                birthday: null,
                phone: null,
                address: null,
                email: null,
                confirm_email: null,
                confirm_phone: null,
                available_record_today: null,
            });

            commit('apiToken', null);

            commit('analyzes', []);
            commit('visitsPast', []);
            commit('visitsCurrent', []);

            if (reload) {
                window.location.reload(true);
            }
        },
        updateInfo({state, commit}) {
            return info(state.auth.api_token)
                .then(({
                           id, login, name, birthday, phone, address, email, confirm_email, confirm_phone,
                           available_record_today
                       }) => {
                    commit('authUser', {
                        id,
                        login,
                        name,
                        birthday,
                        phone,
                        address,
                        email,
                        confirm_email,
                        confirm_phone,
                        available_record_today,
                    });
                });
        },
        register({dispatch}, payload) {
            return register(payload)
                .catch(error => dispatch('handleError', error));
        },
        restorePassword({dispatch}, payload) {
            return restorePassword(payload)
                .catch(error => dispatch('handleError', error));
        },
        changePassword({state, dispatch}, payload) {
            return changePassword(payload, state.auth.api_token)
                .catch(error => dispatch('handleError', error));
        },
        getAnalyzes({state, commit, dispatch}) {
            return getAnalyzes(state.auth.api_token)
                .catch(error => dispatch('handleError', error))
                .then(analyzes => {
                    commit('analyzes', analyzes);
                });
        },
        getAnalyze({state, dispatch}, payload) {
            return getAnalyze(payload, state.auth.api_token)
                .catch(error => dispatch('handleError', error));
        },
        getVisitsPast({state, commit, dispatch}) {
            return getVisitsPast(state.auth.api_token)
                .catch(error => dispatch('handleError', error))
                .then(visitsPast => {
                    commit('visitsPast', visitsPast);
                });
        },
        getVisitsCurrent({state, commit, dispatch}) {
            return getVisitsCurrent(state.auth.api_token)
                .catch(error => dispatch('handleError', error))
                .then(visitsCurrent => {
                    commit('visitsCurrent', visitsCurrent);
                });
        },
        setVisitCurrentCancel({state, dispatch}, payload) {
            return setVisitsCurrentCancel(payload, state.auth.api_token)
                .catch(error => dispatch('handleError', error));
        },
        getVisitDocument({state, dispatch}, payload) {
            return getVisitDocument(payload, state.auth.api_token)
                .catch(error => dispatch('handleError', error));
        },
        getVisitPaymentLink({state, dispatch}, payload) {
            return getVisitsPaymentLink(payload, state.auth.api_token)
                .catch(error => dispatch('handleError', error));
        },
        getDoctors({dispatch}, payload) {
            return getDoctors(payload)
                .catch(error => dispatch('handleError', error));
        },
        getSpecializations({dispatch}) {
            return getSpecializations()
                .catch(error => dispatch('handleError', error));
        },
        getDiagnosticTypes({dispatch}) {
            return getDiagnosticTypes()
                .catch(error => dispatch('handleError', error));
        },
        getDiagnostics({dispatch}, payload) {
            return getDiagnostics(payload)
                .catch(error => dispatch('handleError', error));
        },
        getClinics({dispatch}) {
            return getClinics()
                .catch(error => dispatch('handleError', error));
        },
        getSliders({dispatch}) {
            return getSliders()
                .catch(error => dispatch('handleError', error));
        },
        getDoctorTimeTables({state, dispatch}, payload) {
            return getDoctorTimeTables(payload, state.auth.api_token)
                .catch(error => dispatch('handleError', error));
        },
        getDoctorTimeTableInfo({state, dispatch}, payload) {
            return getDoctorTimeTableInfo(payload, state.auth.api_token)
                .catch(error => dispatch('handleError', error));
        },
        orderGuestDoctorTimeTable({state, dispatch}, payload) {
            return orderGuestDoctorTimeTable(payload)
                .catch(error => dispatch('handleError', error))
                .then(({meta: {reservation}}) => {
                    return reservation
                });
        },
        confirmGuestDoctorTimeTable({state, dispatch}, payload) {
            return confirmGuestDoctorTimeTable(payload)
                .catch(error => dispatch('handleError', error))
                .then((data) => {
                    return data
                });
        },
        orderDoctorTimeTable({state, dispatch}, payload) {
            return orderDoctorTimeTable(payload, state.auth.api_token)
                .catch(error => dispatch('handleError', error))
                .then(({id, meta: {visit_id}}) => {
                    if (visit_id) {
                        return dispatch('getVisitPaymentLink', visit_id);
                    }

                    return {
                        id,
                    }
                });
        },
        orderDoctor({state, dispatch}, payload) {
            return orderDoctor(payload, state.auth.api_token)
                .catch(error => dispatch('handleError', error));
        },
        getDiagnosticTimeTables({state, dispatch}, payload) {
            return getDiagnosticTimeTables(payload, state.auth.api_token)
                .catch(error => dispatch('handleError', error));
        },
        getDiagnosticTimeTableInfo({state, dispatch}, payload) {
            return getDiagnosticTimeTableInfo(payload, state.auth.api_token)
                .catch(error => dispatch('handleError', error));
        },
        orderGuestDiagnosticTimeTable({state, dispatch}, payload) {
            return orderGuestDiagnosticTimeTable(payload)
                .catch(error => dispatch('handleError', error))
                .then(({meta: {reservation}}) => {
                    return reservation
                });
        },
        confirmGuestDiagnosticTimeTable({state, dispatch}, payload) {
            return confirmGuestDiagnosticTimeTable(payload)
                .catch(error => dispatch('handleError', error))
                .then((data) => {
                    return data
                });
        },
        orderDiagnosticTimeTable({state, dispatch}, payload) {
            return orderDiagnosticTimeTable(payload, state.auth.api_token)
                .catch(error => dispatch('handleError', error))
                .then(({id, meta: {visit_id}}) => {
                    if (visit_id) {
                        return dispatch('getVisitPaymentLink', visit_id);
                    }

                    return {
                        id,
                    }
                });
        },
        clearError({commit}) {
            commit('error', null);
        },
        clearSuccess({commit}) {
            commit('success', null);
        },
    },
    strict: true,
});

export default store;
