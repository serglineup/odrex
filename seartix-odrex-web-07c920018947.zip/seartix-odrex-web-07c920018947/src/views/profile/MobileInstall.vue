<template>
    <div class="dashboard profile__header">
        <div class="col-md-5 dashboard__app-wrapper mx-auto">
            <div class="dashboard__app">
                <h2>Устанавливайте приложение Odrex</h2>
                <div>Результаты исследований, анализы и заключения всегда под рукой.</div>
                <div class="dashboard__buttons">
                    <a href="https://www.apple.com" class="dashboard__button dashboard__button-app"></a>
                    <a href="https://play.google.com/store" class="dashboard__button dashboard__button-google"></a>
                </div>
            </div>
        </div>
    </div>
</template>