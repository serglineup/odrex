<template>
    <div class="dashboard profile__header">
        <div class="col-md-8">
            <p>
                Извините, исчерпан лимит записей в день.<br>
                Для записи обратитесь в call-центр по номеру:<br>
                <a href="tel:+380487300030">
                    +38 (048) 730-00-30
                </a>
            </p>
        </div>
    </div>
</template>

<style scoped>
    p {
        font-size: 1.5rem;
    }
</style>